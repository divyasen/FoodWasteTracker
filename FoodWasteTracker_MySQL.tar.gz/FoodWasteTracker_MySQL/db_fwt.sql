CREATE DATABASE IF NOT EXISTS food_waste_tracker;
USE food_waste_tracker;

CREATE TABLE IF NOT EXISTS food_subgroup (
    fsg_id INT (5) NOT NULL,
    fsg_desc VARCHAR (50),
    PRIMARY KEY (fsg_id)
);

CREATE TABLE IF NOT EXISTS food_group (
    fg_id INT (5) NOT NULL,
    fg_desc VARCHAR (50),
    PRIMARY KEY (fg_id)
);

CREATE TABLE IF NOT EXISTS price (
    fsg_id INT (5) NOT NULL,
    mkg_id INT (5) NOT NULL,
    year YEAR NOT NULL,
    quarter INT (1) NOT NULL,
    unit_price_g_avg DOUBLE (10, 2),
    standard_error DOUBLE (10, 9),
    PRIMARY KEY (fsg_id, mkg_id, year, quarter)
);

CREATE TABLE IF NOT EXISTS location (
    mkg_id INT (5) NOT NULL,
    mkg_desc VARCHAR (50),
    div_id INT (5),
    div_desc VARCHAR (50),
    region_id INT (5),
    region_desc VARCHAR (50),
    PRIMARY KEY (mkg_id)    
);

CREATE TABLE IF NOT EXISTS food (
    ndb_no INT (5) NOT NULL,
    food_desc VARCHAR (100),
    #46nutrients

    water_g DOUBLE(10, 3),
    energ_kcal DOUBLE(10, 3),
    protein_g DOUBLE(10, 3),
    lipid_tot_g DOUBLE(10, 3),
    ash_g DOUBLE(10, 3),
    carbohydrt_g DOUBLE(10, 3),
    fiber_td_g DOUBLE(10, 3),
    sugar_tot_g DOUBLE(10, 3),
    calcium_mg DOUBLE(10, 3),
    iron_mg DOUBLE(10, 3),
    magnesium_mg DOUBLE(10, 3),
    phosphorus_mg DOUBLE(10, 3),
    potassium_mg DOUBLE(10, 3),
    sodium_mg DOUBLE(10, 3),
    zinc_mg DOUBLE(10, 3),
    copper_mg DOUBLE(10, 3),
    manganese_mg DOUBLE(10, 3),
    selenium_g DOUBLE(10, 3),
    vit_c_mg DOUBLE(10, 3),
    thiamin_mg DOUBLE(10, 3),
    riboflavin_mg DOUBLE(10, 3),
    niacin_mg DOUBLE(10, 3),
    panto_acid_mg DOUBLE(10, 3),
    vit_b6_mg DOUBLE(10, 3),
    folate_tot_g DOUBLE(10, 3),
    folic_acid_g DOUBLE(10, 3),
    food_folate_g DOUBLE(10, 3),
    folate_dfe_g DOUBLE(10, 3),
    choline_tot_mg DOUBLE(10, 3),
    vit_b12_g DOUBLE(10, 3),
    vit_a_iu DOUBLE(10, 3),
    vit_a_rae DOUBLE(10, 3),
    retinol_g DOUBLE(10, 3),
    alpha_carot_g DOUBLE(10, 3),
    beta_carot_g DOUBLE(10, 3),
    beta_crypt_g DOUBLE(10, 3),
    lycopene_g DOUBLE(10, 3),
    lutzea_g DOUBLE(10, 3),
    vit_e_mg DOUBLE(10, 3),
    vit_d_g DOUBLE(10, 3),
    vit_d_iu DOUBLE(10, 3),
    vit_k_g DOUBLE(10, 3),
    fa_sat_g DOUBLE(10, 3),
    fa_mono_g DOUBLE(10, 3),
    fa_poly_g DOUBLE(10, 3),
    cholestrl_mg DOUBLE(10, 3),

    PRIMARY KEY (ndb_no)
);

CREATE TABLE IF NOT EXISTS unit_conversion (
    ndb_no INT (5) NOT NULL,
    value_a DOUBLE (10, 9),
    name_a VARCHAR (20),
    value_b DOUBLE (10, 9),
    name_b VARCHAR (20),
    PRIMARY KEY (ndb_no)
);

CREATE TABLE IF NOT EXISTS food_food_group (
    ndb_no INT (5) NOT NULL,
    fg_id INT (5),
    PRIMARY KEY (ndb_no)
);

CREATE TABLE IF NOT EXISTS food_subgroup_group(
    fsg_id INT (5) NOT NULL,
    fg_id INT (5) NOT NULL,
    PRIMARY KEY (fsg_id, fg_id)
);

CREATE TABLE IF NOT EXISTS user_input (
    uid INT (5) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    ndb_no INT (5),
    fsg_id INT (5),
    mkg_id INT (5),
    year YEAR,
    quarter INT (1),
    weight DOUBLE (10, 9),
    PRIMARY KEY (uid, date, time)
);

CREATE TABLE IF NOT EXISTS visitors (
    identifier VARCHAR (512) NOT NULL,
    uid INT (5) NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (uid)
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/food_subgroup_table.tsv' INTO TABLE food_subgroup
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    fsg_id,
    fsg_desc
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/food_group_table.tsv' INTO TABLE food_group
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    fg_id,
    fg_desc
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/price_table.tsv' INTO TABLE price
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    fsg_id,
    mkg_id,
    year,
    quarter,
    unit_price_g_avg,
    standard_error
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/location_table.tsv' INTO TABLE location
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    mkg_id,
    mkg_desc,
    div_id,
    div_desc,
    region_id,
    region_desc
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/food_table.tsv' INTO TABLE food
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    ndb_no,
    food_desc,
    water_g,
    energ_kcal,
    protein_g,
    lipid_tot_g,
    ash_g,
    carbohydrt_g,
    fiber_td_g,
    sugar_tot_g,
    calcium_mg,
    iron_mg,
    magnesium_mg,
    phosphorus_mg,
    potassium_mg,
    sodium_mg,
    zinc_mg,
    copper_mg,
    manganese_mg,
    selenium_g,
    vit_c_mg,
    thiamin_mg,
    riboflavin_mg,
    niacin_mg,
    panto_acid_mg,
    vit_b6_mg,
    folate_tot_g,
    folic_acid_g,
    food_folate_g,
    folate_dfe_g,
    choline_tot_mg,
    vit_b12_g,
    vit_a_iu,
    vit_a_rae,
    retinol_g,
    alpha_carot_g,
    beta_carot_g,
    beta_crypt_g,
    lycopene_g,
    lutzea_g,
    vit_e_mg,
    vit_d_g,
    vit_d_iu,
    vit_k_g,
    fa_sat_g,
    fa_mono_g,
    fa_poly_g,
    cholestrl_mg
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/unit_conversion_table.tsv' INTO TABLE unit_conversion
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    ndb_no,
    value_a,
    name_a,
    value_b,
    name_b
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/food_food_group_table.tsv' INTO TABLE food_food_group
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    ndb_no,
    fg_id
);

LOAD DATA LOCAL INFILE '/tmp/db_fwt_dataset_tsv/food_subgroup_group_table.tsv' INTO TABLE food_subgroup_group
FIELDS TERMINATED BY '\t' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(
    fg_id,
    fsg_id
);
