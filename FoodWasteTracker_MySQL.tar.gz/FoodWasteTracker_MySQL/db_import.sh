#!/bin/bash

# This script creates the database 'food_waste_tracker' and its
# associated tables.
#
# Then, it loads the database with tab-separated datasets, and 
# checks whether all of the tables were successfully populatd.
#
# Version   2016.04.09

USAGE[0]="Usage: $0 <FLAGS>"
USAGE[1]="Flags:"
USAGE[4]="    -u <USERNAME>         REQUIRED"
USAGE[5]="    -p <PASSWORD>"
USAGE[6]="    -v                    Creates and imports in verbose mode"
CMD="mysql --local-infile"
VERBOSE=false

# Used to indicate a piece of information the user did not provide
function highlight_line {
    USAGE["$1"]="$(echo "${USAGE[$1]}" | sed -e 's/../**/1')    ****"
}

# Adds the credentials required to login into the mysql server
function load_conn_info {
    if [[ "$VERBOSE" = true ]]; then
        # Runs MySQL in verbose mode
        CMD="$CMD --verbose"
    fi

    if [[ -z "$USERNAME" || "$USERNAME" == "-p" ]]; then
        # The user enabled the "use a password" flag, but did not give one
        highlight_line 4
        printf '%s\n' "${USAGE[@]}"
        echo "$USERNAME"
        echo "$CMD"
        exit 1
    fi

    # The user's username for managing the MySQL server
    CMD="$CMD -u $USERNAME"

    if [[ ! -z "$PASSWORD" ]]; then
        # The user wants to login to an account that requires a password
        CMD="$CMD --password=$PASSWORD"
    fi

}

# Processes the user's inputs
while getopts ":u:p:v" flags; do
    case "${flags}" in
        u)
            USERNAME="$OPTARG"
            ;;
        p)
            PASSWORD="$OPTARG"
            ;;
        v)
            VERBOSE=true
            ;;
        /?)
            echo "Invalid options: -$OPTARG" >&2
            ;;
        *)
            printf '%s\n' "${USAGE[@]}";
            exit 1
            ;;
    esac
done
shift $((OPTIND - 1))

# Adds the credential required to login into the mysql server
load_conn_info

# Copies dataset to temporary folder for SQL commands to access
mkdir -m 700 -p /tmp/db_fwt_dataset_tsv
cp dataset_tsv/*.tsv /tmp/db_fwt_dataset_tsv/

# Executes the included .sql file
bash -c "$CMD < db_fwt.sql"

# Clean-ups temporary files created for the import process
rm -drf /tmp/db_fwt_dataset_tsv

# Test that all data has been imported correctly
cd ./test_files
if [[ $VERBOSE = true ]]; then
    # Only notifies the user of test in progress when verbose run is enabled
    echo "Testing dataset load success:"
fi
EXIT_CODE=0
# Checks each table's non-null row count
for f in ./*.expected; do
    COUNT_CMD="$(head -n 1 ./$f)"
    TABLE_NAME=$(basename $f .expected)
    OUTPUT=$($CMD -e "use food_waste_tracker; select $COUNT_CMD from $TABLE_NAME;")
    OUTPUT=${OUTPUT##*$'\n'}
    EXPECTED=$(tail -n 1 $f)
    if [[ -z $(diff <(echo "$OUTPUT") <(echo "$EXPECTED")) ]]; then
        # OUTPUT matches EXPECTED
        # The table has the expected number of non-null rows
        if [[ $VERBOSE = true ]]; then
            # Provides feedback only when verbose run is enabled
            STATUS_PROMPT="'$TABLE_NAME' load:"
            printf "%-32s" "$STATUS_PROMPT"
            printf "[OK]\n"
        fi
    else
        # When the count of rows in a given table does not match
        # what is expected, a message will be printed regardless of
        # verbose run or not
        STATUS_PROMPT="'$TABLE_NAME' load:"
        printf "%-32s" "$STATUS_PROMPT"
        printf "[FAIL]\n"
        echo "--------------------"
        echo "EXPECTED:"
        echo "\"$EXPECTED\""
        echo "--------------------"
        echo "RESULT:"
        echo "\"$OUTPUT\""
        echo "========================================"
        EXIT_CODE=-1
    fi
done

# Exits without error (0) if all the data was loaded, after 
# the schema was created properly; exits with error (-1 or 255) if otherwise
exit $EXIT_CODE
